package com.example.daftarversiandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.daftarversiandroid.adapter.ListAndroidAdapter;
import com.example.daftarversiandroid.adapter.OnItemClickCallback;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvandroid;
    private ArrayList<Android> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvandroid = findViewById(R.id.rv_android);
        rvandroid.setHasFixedSize(true);

        list.addAll(DataAndroid.getListData());
        showRecycleList();
    }

    private void showRecycleList() {
        rvandroid.setLayoutManager(new LinearLayoutManager(this));
        ListAndroidAdapter listAndroidAdapter = new ListAndroidAdapter(list);
        rvandroid.setAdapter(listAndroidAdapter);

        listAndroidAdapter.setOnItemClickCallback(new OnItemClickCallback(){
            @Override
            public void onItemClicked(Android android) {
                Intent moveIntent1 = new Intent(MainActivity.this, DetailAndroid.class);
                moveIntent1.putExtra(DetailAndroid.ITEM_EXTRA, android);
                startActivity(moveIntent1);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_activity_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        if (item.getItemId() == R.id.about_id){
            Intent moveIntent = new Intent(MainActivity.this, AboutActivity.class);
            startActivity(moveIntent);
        }
        return super.onOptionsItemSelected(item);
    }
}