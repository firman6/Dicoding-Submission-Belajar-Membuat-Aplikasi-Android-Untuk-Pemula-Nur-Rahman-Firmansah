package com.example.daftarversiandroid;

import java.util.ArrayList;

public class DataAndroid {
    private static String[] androidNames = {
            "Alpha",
            "Beta",
            "Cupcake",
            "Donut",
            "Eclair",
            "Froyo",
            "Gingerbread",
            "Honeycomb",
            "Ice Cream Sandwich",
            "Jelly Bean",
            "Kitkat",
            "Lollipop",
            "Marshmallow",
            "Nougat",
            "Oreo",
            "Pie",
            "Android 10"
    };

    private static String[] androidDetails = {
            "Pada versi awal, android menggunakan nama-nama yang berasal dari robor fiktif. Versi pertama android 1.0 dinamakan Android Astro Boy. Namun sayang, karena hak cipta penggunaan merk, versi yang dirilis 23 September 2009 ini tidak digunakan secara komersil. Versi ini sempat digunakan pada ponsel jenis HTC dream. Selain itu, logo pertama android yang dibuat oleh Irina Blok juga diluncurkan secara perdana.",
            "Android versi 1.1 muncul di tanggal 9 Februari 2009, Namun, karena hak cipta penamaan, sama seperti android pertamanya, Android yang tadinya diberi codename bender juga tidak rilis secara komersial.",
            "Untuk pertama kalinya, Google memberikan nickname untuk versi Android yang diambil dari nama-nama makanan. Android cupcake dibekali dengan on-screen keyboard seiring dengan semakin populernya perangkat layar sentuh pada masa itu.Pada versi ini pula untuk pertama kalinya Android didukung dengan aplikasi camcorder untuk merekam video.Tren sharing konten multimedia pun ditanggapi pihak Google dengan fasilitas upload video ke YouTube dan upload foto ke Picasa. Fitur widgets pun mulai dibuka kepada pihak ketiga untuk meningkatkan pengalaman pengguna.Google Calendar juga pertama kali disematkan pada versi ini, begitu pula dengan aplikasi Music yang sebelumnya ditangani oleh Amazon MP3.Selain Calendar dan Music, Google Talk juga pertama kali dirilis di Android Cupcake. Fitur auto rotasi pun ditambahkan untuk memudahkan pengguna dalam mengubah orientasi layar ke portrait atau landscape. Android Cupcake juga mendukung copy-paste ke web browser yang sebelumnya hanya bisa dilakukan di kolom input.",
            "Di versi ini, Android mulai mendukung perangkat CDMA. Untuk pertama kalinya pula Android mendukung resolusi layar ganda. Pembaruan besar-besaran dilakukan pada Android Market dan status Beta pun dicabut di versi Donut.Beberapa fitur terbaru Android Market di antaranya tampilan yang sebelumnya berwarna dasar hitam menjadi lebih berwarna dengan perpaduan putih, abu-abu, dan hijau.Pengguna pun bisa mengurutkan aplikasi berdasarkan kategori Top Paid (berbayar), Top Free (gratis), dan Just In (Terbaru). Pihak developer aplikasi pun bisa menyertakan screenshot dimana sebelumnya hanya bisa menampilkan deskripsi dan review dari pengguna.",
            "Untuk pertama kalinya, Google Maps dibekali dengan fitur Navigation dimana pengguna bisa mendapatkan panduan rute ke lokasi tertentu. Pengguna juga bisa menggunakan lebih dari satu akun Google di perangkat yang sama.Pembaruan juga banyak diberikan untuk aplikasi Web Browser. Di Android Eclair, pengguna bisa melakukan pencarian dengan mengetikkan kata kunci di address bar, menyimpan bookmark dengan gambar thumbnail dari situs web, double-tap untuk zoom-in dan zoom-out, serta dukungan untuk HTML5.Tombol on-screen mulai diperkenalkan sehingga produsen mobile bisa menghilangkan tombol fisik untuk perangkat Android. Camera juga diperbarui dengan fitur flash dan opsi untuk menyimpan foto di penyimpanan internal maupun SD card.",
            "Just In Time (JIC) compiler meningkatkan kecepatan Android secara drastis. Chrome dibekali dengan API terbaru untuk memindahkan konten secara cepat dari desktop ke smartphone Android. Web browser juga mendapatkan pembaruan V8 yang meningkatkan kecepatan sekitar dua hingga lima kali lipat. Dukungan untuk Flash pun diberikan agar pengguna bisa mengakses semua fitur multimedia di situs web.Android Froyo adalah versi pertama yang mendukung instalasi aplikasi ke SD Card untuk melonggarkan kapasitas penyimpanan internal. Perangkat Android pun mulai bisa digunakan sebagai hotspot untuk berbagi koneksi internet dengan perangkat lain.Android Market menyediakan fitur auto update untuk aplikasi-aplikasi yang dipilih pengguna. Aplikasi terbaru yang dirilis di Android Froyo adalah Google Goggles dan Twitter.",
            "On-screen keyboard mengalami pembaruan penting untuk meningkatkan kecepatan dan akurasi pengetikan. Fitur suggestions pun mulai ditambahkan pada versi ini.Fitur copy paste dilengkapi dengan tanda panah di kedua bagian teks agar pengguna bisa dengan mudah memilih bagian tertentu dari suatu teks. Dukungan untuk Near Field Communication (NFC) juga pertama kali ditambahkan pada Android Gingerbread.Selain itu, dukungan untuk kamera depan juga dimulai dari versi ini, yang kemudian membawa pengguna pada tren selfie.",
            "Ini adalah versi Android dibawah arahan desain dari Matias Duarte dan pertama kalinya menggunakan tampilan Holo (holographic). Android Honeycomb pada awalnya diluncurkan khusus untuk perangkat tablet.Google kemudian merilis API Fragments yang menghasilkan berbagai ukuran layar smartphone untuk kemudian ditampilkan di layar tablet. Status bar dipindahkan ke bagian bawah layar dan secara otomatis menjadi samar saat pengguna menjalankan aplikasi, sehingga aplikasi menempati layar secara penuh.Android Honeycomb juga memungkinkan pengguna untuk membuka lebih dari 1 tab saat browsing dan menggunakan mode incognito. Selain itu, pengguna juga bisa melakukan sinkronisasi Chrome dengan versi desktop.",
            "Android Ice Cream Sandwich menggantikan Honecomb secara total sehingga saat ini tidak ada satu perangkat pun yang menjalankan Honeycomb. Semua navigasi bisa dijalankan secara on-screen sehingga perangkat Android hanya membutuhkan dua tombol fisik yaitu power dan volume.Ukuran Widgets bisa diatur sesuai keinginan pengguna. Konten yang ditampilkan pun menyesuaikan ukuran Widgets. Gesture Swipe mulai digunakan untuk menutup notifikasi, recent apps dan tab browser. Keyboard dilengkapi dengan fitur spell-checker dan menandai kesalahan pengetikan dengan underline berwarna merah, serta menampilkan saran kata yang benar.",
            "Pada versi ini, Google Now mendapatkan pembaruan besar dengan akses yang jauh lebih mudah. Hanya dengan sekali swipe dari home screen, pengguna bisa mengakses berbagai informasi penting seperti kalender, email, laporan cuaca, dan lain sebagainya.Terobosan lain yang disematkan Google ke Jelly Bean adalah Project Butter yang membuat Android jauh lebih smooth dan user friendly.",
            "Google melakukan modernisasi tampilan sehingga tampak lebih cerah dan menarik. Aksen biru di versi Ice Cream Sandwich dan Jelly Bean digantikan dengan aksen putih. Beberapa aplikasi juga diperbarui dengan skema warna yang lebih terang.Perintah “Ok, Google” yang populer digunakan untuk melakukan pencarian juga pertama kali diperkenalkan di Android KitKat.",
            "Versi ini adalah yang pertama kalinya menerapkan filosofi Material Design. Google juga menggantikan Dalvik VM dengan Android Runtime untuk mempercepat proses kompilasi. Dengan demikian, aplikasi dapat berjalan dengan lebih cepat dan lancar daripada versi-versi sebelumnya.Selain itu, pembaruan juga diberikan ke beberapa bagian lain seperti notifikasi, dukungan untuk RAW image, dan masih banyak lagi.",
            "Latar belakang tampilan menu aplikasi diubah menjadi warna putih dengan kolom pencarian untuk memudahkan pengguna dalam mencari aplikasi tertentu. Marshmallow juga menyediakan fitur terbaru di Memory Manager untuk melihat penggunaan memori selama 3, 6, 12, dan 24 jam sebelumnya.Kontrol volume pun dipisah untuk perangkat, media, dan alarm. Dari segi keamanan, Android Marshmallow adalah versi pertama yang mendukung autentikasi sidik jari (fingerprint).",
            "Asisten digital yang sebelumnya bernama Google Now, di versi ini diubah menjadi Google Assistant. Notifikasi pun mendapatkan pembaruan besar berupa pengelompokan pemberitahuan sehingga lebih efisien.Nougat juga mendukung multitasking yang memungkinkan pengguna untuk melakukan splitting antar aplikasi. Dengan demikian, pengguna bisa membuka aplikasi lain tanpa harus menutup aplikasi yang sedang dijalankan.",
            "Multitasking di versi ini sudah jauh lebih canggih. Pengguna bisa tetap menontoj Netflix sembari berselancar di web browser. Notifikasi juga bisa dipersonalisasi lebih jauh dimana pengguna bisa memilih untuk menyalakan atau mematikan notifikasi dari aplikasi tertentu.Pengguna juga bisa mengurutkan notifikasi berdasarkan skala prioritas aplikasi. Untuk pertama kalinya pula Android memiliki fitur notifikasi dot berupa icon kecil yang tampil di bagian atas layar.",
            "Pie dirilis ketika sistem operasi Android telah berumur 10 tahun sejak versi pertamanya diluncurkan. Digital Wellbeing adalah fitur terbaru Android Pie yang digunakan untuk memantau durasi penggunaan smartphone, aplikasi yang paling sering digunakan, dan sebagainya. Hal ini bertujuan untuk mengurangi ketergantungan pengguna terhadap smartphone.Notifikasi pun diperbarui kembali dengan fitur kontrol yang lebih lengkap. Sejak Android Pie, pengguna bisa menyalakan atau mematikan notifikasi tertentu dari tiap aplikasi yang mereka gunakan.",
            "Tanggal rilis : September 2019 Fitur Baru : tema gelap, smart reply, navigasi gestur baru, kontrol lokasi, live caption, focus mode, naotifikasi intuitif, familiy link update, project mainline dll. Sampai tulisan ini dibuat (Juni 2020) Android 10 adalah versi paling baru dari Android. Pada versi Beta, Google menggunakan codename Android Q untuk versi ini.Namun pada saat official release, pihak Google menyatakan Android 10 dirilis tanpa nama makanan manis layaknya versi-versi sebelumnya.Maskot logo android pun berubah, dari awalnya berbentuk tubuh robot bertangan, berkaki, berbadan dan berkepala. Dalam versi ini hanya berbentuk kepala andoid dan antenanya saja.",

    };

    private static int[] androidImages = {
            R.drawable.alpha,
            R.drawable.beta,
            R.drawable.cupcake,
            R.drawable.donut,
            R.drawable.eclair,
            R.drawable.froyo,
            R.drawable.gingerbread,
            R.drawable.honeycomb,
            R.drawable.ice_cream_sandwich,
            R.drawable.jellybean,
            R.drawable.kitkat,
            R.drawable.lollipop,
            R.drawable.marshmallow,
            R.drawable.nougat,
            R.drawable.oreo,
            R.drawable.pie,
            R.drawable.q_10
    };

    static ArrayList<Android> getListData(){
        ArrayList<Android> list = new ArrayList<>();
        for (int position = 0; position < androidNames.length; position++){
            Android android = new Android();
            android.setNama(androidNames[position]);
            android.setDetail(androidDetails[position]);
            android.setPhoto(androidImages[position]);
            list.add(android);
        }
        return list;
    }
}
