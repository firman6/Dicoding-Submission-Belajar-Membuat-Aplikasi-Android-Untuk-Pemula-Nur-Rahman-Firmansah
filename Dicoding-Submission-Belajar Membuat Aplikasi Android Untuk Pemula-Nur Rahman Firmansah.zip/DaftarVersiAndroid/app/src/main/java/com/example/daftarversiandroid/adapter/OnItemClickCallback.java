package com.example.daftarversiandroid.adapter;

import com.example.daftarversiandroid.Android;

public interface OnItemClickCallback {
    void onItemClicked(Android android);
}
